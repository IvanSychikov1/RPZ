# LB-DOCKER
1. [Скріншот 1](https://github.com/MKroppp/LB-DOCKER/blob/main/Screenshots/1.png) - git clone https://github.com/docker/getting-started-todo-app - Клонування репозиторію, cd getting-started-todo-app - Перехід у директорію створеного репозиторію, docker compose watch - Команда для запуску проєкту.
2. [Скріншот 2](https://github.com/MKroppp/LB-DOCKER/blob/main/Screenshots/2.png) - Запущений застосунок.
3. [Скріншот 3](https://github.com/MKroppp/LB-DOCKER/blob/main/Screenshots/3.png) - Внесення змін до коду додатка.
4. [Скріншот 4](https://github.com/MKroppp/LB-DOCKER/blob/main/Screenshots/4.png) - Результат.
5. [Скріншот 5](https://github.com/MKroppp/LB-DOCKER/blob/main/Screenshots/5.png) - Внесення змін до коду додатка.
6. [Скріншот 6](https://github.com/MKroppp/LB-DOCKER/blob/main/Screenshots/6.png) - Результат.
7. [Скріншот 7](https://github.com/MKroppp/LB-DOCKER/blob/main/Screenshots/7.png) - Внесення змін до коду додатка.
8. [Скріншот 8](https://github.com/MKroppp/LB-DOCKER/blob/main/Screenshots/8.png) - Результат.
9. [Скріншот 9](https://github.com/MKroppp/LB-DOCKER/blob/main/Screenshots/9.png) - Перехід у Docker Hub, Створення свого репозиторію.
10. [Скріншот 10](https://github.com/MKroppp/LB-DOCKER/blob/main/Screenshots/11.png) - Створення проєкту, docker image ls - Перевірка існування локального зображення, docker push DOCKER_USERNAME/getting-started-todo-app - Надсилання зображення в репозиторій.
11. [Скріншот 11](https://github.com/MKroppp/LB-DOCKER/blob/main/Screenshots/10.png) - Результат.
